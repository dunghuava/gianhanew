CHANGELOG
=========

0.1.4 (2014-07-23)
------------------
* Added support to load different path for template views (this feature is only available in CI v3.0)

0.1.3 (2014-06-17)
------------------

* Fix sending email in plain/text format only

0.1.2 (2014-04-27)
------------------

* Initial release
